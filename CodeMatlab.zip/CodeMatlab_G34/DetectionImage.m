function varargout = DetectionImage(varargin)
% DETECTIONIMAGE MATLAB code for DetectionImage.fig
%      DETECTIONIMAGE, by itself, creates a new DETECTIONIMAGE or raises the existing
%      singleton*.
%
%      H = DETECTIONIMAGE returns the handle to a new DETECTIONIMAGE or the handle to
%      the existing singleton*.
%
%      DETECTIONIMAGE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DETECTIONIMAGE.M with the given input arguments.
%
%      DETECTIONIMAGE('Property','Value',...) creates a new DETECTIONIMAGE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DetectionImage_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DetectionImage_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DetectionImage

% Last Modified by GUIDE v2.5 12-Sep-2020 22:32:15

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DetectionImage_OpeningFcn, ...
                   'gui_OutputFcn',  @DetectionImage_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before DetectionImage is made visible.
function DetectionImage_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DetectionImage (see VARARGIN)

% Choose default command line output for DetectionImage
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes DetectionImage wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = DetectionImage_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Importer l'image
[FileName,PathName] = uigetfile({'*.*'});
handles.fullPath = [PathName,FileName];
%Lecture de l'image
handles.im = imread(handles.fullPath);
axes(handles.axes1); cla; imshow(handles.im);
guidata(hObject,handles);


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.G=rgb2gray(handles.im);
handles.Pre=edge(handles.G,'prewitt');
handles.Rob=edge(handles.G,'roberts');
handles.Can=edge(handles.G,'canny');
handles.Sob=edge(handles.G,'sobel');

figure;
subplot(2, 2, 1); imshow(handles.Pre);  title('Prewitt'); 
subplot(2, 2, 2); imshow(handles.Rob); title('Roberts');
subplot(2, 2, 3); imshow(handles.Can); title('Canny');
subplot(2, 2, 4); imshow(handles.Sob); title('Sobel');
guidata(hObject, handles);


% --- Executes on button press in Retour.
function Retour_Callback(hObject, eventdata, handles)
% hObject    handle to Retour (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
open(MenuInterface);


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1

contents=get(hObject,'Value');

switch contents

    case 1  %Prewitt
        handles.s = 1;
        handles.Pre=rgb2gray(handles.im);
        handles.Pre=edge(handles.Pre,'prewitt');
        axes(handles.axes2); cla; imshow(handles.Pre);
        guidata(hObject,handles);
        
    case 2  %Roberts
        handles.s = 2;
        handles.Rob=rgb2gray(handles.im);
        handles.Rob=edge(handles.Rob,'roberts');
        axes(handles.axes2); cla; imshow(handles.Rob);
        guidata(hObject,handles);
 
    case 3  %Canny
        handles.s = 3;
        handles.Can=rgb2gray(handles.im);
        handles.Can=edge(handles.Can,'canny');
        axes(handles.axes2); cla; imshow(handles.Can);
        guidata(hObject,handles);
        
    case 4 % Sobel 
        handles.s = 4;
        handles.Sob=rgb2gray(handles.im);
        handles.Sob=edge(handles.Sob,'sobel');
        axes(handles.axes2); cla; imshow(handles.Sob);
        guidata(hObject,handles);
end

% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in pushbutton15.
function pushbutton15_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[file,path]= uiputfile('*.jpg','Save Image as');
save=[path,file]; 

switch handles.s
   case 1
      imwrite(handles.Pre,save,'jpg');
   case 2
      imwrite(handles.Rob,save,'jpg');
   case 3
      imwrite(handles.Can,save,'jpg');
   case 4
      imwrite(handles.Sob,save,'jpg');
end


% --- Executes on button press in pushbutton16.
function pushbutton16_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close all;

% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1

switch handles.s

    case 1  %Prewitt
        handles.P=imnoise(handles.im,'poisson');
        handles.P=rgb2gray(handles.P);
        handles.P=edge(handles.P,'prewitt');
        axes(handles.axes3); cla; imshow(handles.P);
        guidata(hObject,handles);
        
    case 2  %Roberts
        handles.R=imnoise(handles.im,'poisson');
        handles.R=rgb2gray(handles.R);
        handles.R=edge(handles.R,'roberts');
        axes(handles.axes3); cla; imshow(handles.R);
        guidata(hObject,handles);
        
    case 3  %Canny
        handles.C=imnoise(handles.im,'poisson');
        handles.C=rgb2gray(handles.C);
        handles.C=edge(handles.C,'canny');
        axes(handles.axes3); cla; imshow(handles.C);
        guidata(hObject,handles);
        
    case 4 % Sobel 
        handles.S=imnoise(handles.im,'poisson');
        handles.S=rgb2gray(handles.S);
        handles.S=edge(handles.S,'sobel');
        axes(handles.axes3); cla; imshow(handles.S);
        guidata(hObject,handles);
end


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2
switch handles.s

    case 1  %Prewitt
        handles.P=imnoise(handles.im,'gaussian');
        handles.P=rgb2gray(handles.P);
        handles.P=edge(handles.P,'prewitt');
        axes(handles.axes3); cla; imshow(handles.P);
        guidata(hObject,handles);
        
    case 2  %Roberts
        handles.R=imnoise(handles.im,'gaussian');
        handles.R=rgb2gray(handles.R);
        handles.R=edge(handles.R,'roberts');
        axes(handles.axes3); cla; imshow(handles.R);
        guidata(hObject,handles);
        
    case 3  %Canny
        handles.C=imnoise(handles.im,'gaussian');
        handles.C=rgb2gray(handles.C);
        handles.C=edge(handles.C,'canny');
        axes(handles.axes3); cla; imshow(handles.C);
        guidata(hObject,handles);
        
    case 4 % Sobel 
        handles.S=imnoise(handles.im,'gaussian');
        handles.S=rgb2gray(handles.S);
        handles.S=edge(handles.S,'sobel');
        axes(handles.axes3); cla; imshow(handles.S);
        guidata(hObject,handles);
end

% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3
switch handles.s

    case 1  %Prewitt
        handles.P=imnoise(handles.im,'salt & pepper',0.02);
        handles.P=rgb2gray(handles.P);
        handles.P=edge(handles.P,'prewitt');
        axes(handles.axes3); cla; imshow(handles.P);
        guidata(hObject,handles);
        
    case 2  %Roberts
        handles.R=imnoise(handles.im,'salt & pepper',0.02);
        handles.R=rgb2gray(handles.R);
        handles.R=edge(handles.R,'roberts');
        axes(handles.axes3); cla; imshow(handles.R);
        guidata(hObject,handles);
        
    case 3  %Canny
        handles.C=imnoise(handles.im,'salt & pepper',0.02);
        handles.C=rgb2gray(handles.C);
        handles.C=edge(handles.C,'canny');
        axes(handles.axes3); cla; imshow(handles.C);
        guidata(hObject,handles);
        
    case 4 % Sobel 
        handles.S=imnoise(handles.im,'salt & pepper',0.02);
        handles.S=rgb2gray(handles.S);
        handles.S=edge(handles.S,'sobel');
        axes(handles.axes3); cla; imshow(handles.S);
        guidata(hObject,handles);
end


% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton4
switch handles.s

    case 1  %Prewitt
        handles.P=imnoise(handles.im,'speckle',0.04);
        handles.P=rgb2gray(handles.P);
        handles.P=edge(handles.P,'prewitt');
        axes(handles.axes3); cla; imshow(handles.P);
        guidata(hObject,handles);
        
    case 2  %Roberts
        handles.R=imnoise(handles.im,'speckle',0.04);
        handles.R=rgb2gray(handles.R);
        handles.R=edge(handles.R,'roberts');
        axes(handles.axes3); cla; imshow(handles.R);
        guidata(hObject,handles);
        
    case 3  %Canny
        handles.C=imnoise(handles.im,'speckle',0.04);
        handles.C=rgb2gray(handles.C);
        handles.C=edge(handles.C,'canny');
        axes(handles.axes3); cla; imshow(handles.C);
        guidata(hObject,handles);
        
    case 4 % Sobel 
        handles.S=imnoise(handles.im,'speckle',0.04);
        handles.S=rgb2gray(handles.S);
        handles.S=edge(handles.S,'sobel');
        axes(handles.axes3); cla; imshow(handles.S);
        guidata(hObject,handles);
end
